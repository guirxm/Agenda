package com.example.Agenda.repository;


import com.example.Agenda.entity.Tarefa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TarefaRepository extends JpaRepository<Tarefa, Long> {

    // Método para verificar se já existe um contato com o mesmo nome e telefone
    Optional<Tarefa> findByNomeAndTelefone(String nome, String telefone);

}