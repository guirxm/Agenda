package com.example.Agenda.Service;


import com.example.Agenda.entity.Tarefa;
import com.example.Agenda.repository.TarefaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TarefaService {

    @Autowired
    private TarefaRepository tarefaRepository;

    public List<Tarefa> listarTodas() {
        return tarefaRepository.findAll();
    }

    public Tarefa buscarPorId(Long id) {
        return tarefaRepository.findById(id)
                .orElseThrow(() -> new TarefaNaoEncontradaException("Tarefa com ID " + id + " não encontrada."));
    }

    public Tarefa adicionar(Tarefa tarefa) {
        tarefaRepository.findByTitulo(tarefa.getTitulo())
                .ifPresent(t -> {
                    throw new TarefaDuplicadaException("Já existe uma tarefa com o título: " + tarefa.getTitulo());
                });

        return tarefaRepository.save(tarefa);
    }

    public Tarefa atualizar(Long id, Tarefa tarefaAtualizada) {
        Tarefa tarefaExistente = buscarPorId(id);

        tarefaExistente.setTitulo(tarefaAtualizada.getTitulo());
        tarefaExistente.setDescricao(tarefaAtualizada.getDescricao());
        tarefaExistente.setDataVencimento(tarefaAtualizada.getDataVencimento());

        return tarefaRepository.save(tarefaExistente);
    }

    public void remover(Long id) {
        if (!tarefaRepository.existsById(id)) {
            throw new TarefaNaoEncontradaException("Tarefa com ID " + id + " não encontrada para remoção.");
        }
        tarefaRepository.deleteById(id);
    }
}