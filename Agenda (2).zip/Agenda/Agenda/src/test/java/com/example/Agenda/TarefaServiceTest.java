package com.example.Agenda;

import com.example.Agenda.Service.TarefaService;
import com.example.Agenda.entity.Tarefa;
import com.example.Agenda.repository.TarefaRepository;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Story;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@Epic("Gerenciamento de Tarefas")
@Feature("Serviço de Tarefas (Simplificado)")
@ExtendWith(MockitoExtension.class)
public class TarefaServiceTest {

    @Mock
    private TarefaRepository tarefaRepository;

    @InjectMocks
    private TarefaService tarefaService;

    @Test
    @Story("Adicionar Tarefa")
    @DisplayName("Deve adicionar uma tarefa com sucesso")
    void deveAdicionarTarefaComSucesso() {
        // Cenário
        Tarefa novaTarefa = new Tarefa("Estudar Docker", "Criar um contêiner", LocalDate.now().plusDays(5));
        when(tarefaRepository.findByTitulo(novaTarefa.getTitulo())).thenReturn(Optional.empty());
        when(tarefaRepository.save(any(Tarefa.class))).thenReturn(novaTarefa);

        // Ação
        Tarefa tarefaSalva = tarefaService.adicionar(novaTarefa);

        // Verificação
        assertNotNull(tarefaSalva);
        assertEquals("Estudar Docker", tarefaSalva.getTitulo());
        verify(tarefaRepository, times(1)).save(novaTarefa);
    }

    @Test
    @Story("Adicionar Tarefa")
    @DisplayName("Deve lançar exceção ao tentar adicionar tarefa com título duplicado")
    void naoDeveAdicionarTarefaDuplicada() {
        // Cenário
        Tarefa tarefaExistente = new Tarefa("Ler documentação", "Ler sobre testes", LocalDate.now());
        when(tarefaRepository.findByTitulo(tarefaExistente.getTitulo())).thenReturn(Optional.of(tarefaExistente));

        // Ação e Verificação
        assertThrows(TarefaDuplicadaException.class, () -> {
            tarefaService.adicionar(tarefaExistente);
        });

        verify(tarefaRepository, never()).save(any(Tarefa.class));
    }
}